﻿namespace Project_Form_1
{
    partial class FrmPatientAppt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPatientAppt));
            this.PatientDatelabel = new System.Windows.Forms.Label();
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.DOBlabel = new System.Windows.Forms.Label();
            this.Commentlabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btnPatientReschedule = new System.Windows.Forms.Button();
            this.btnPatientSave = new System.Windows.Forms.Button();
            this.PatientApptDateTimepicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // PatientDatelabel
            // 
            this.PatientDatelabel.AutoSize = true;
            this.PatientDatelabel.Location = new System.Drawing.Point(16, 9);
            this.PatientDatelabel.Name = "PatientDatelabel";
            this.PatientDatelabel.Size = new System.Drawing.Size(33, 13);
            this.PatientDatelabel.TabIndex = 0;
            this.PatientDatelabel.Text = "Date:";
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.Location = new System.Drawing.Point(16, 39);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(94, 13);
            this.UsernameLabel.TabIndex = 1;
            this.UsernameLabel.Text = "Patient Username:";
            // 
            // DOBlabel
            // 
            this.DOBlabel.AutoSize = true;
            this.DOBlabel.Location = new System.Drawing.Point(16, 68);
            this.DOBlabel.Name = "DOBlabel";
            this.DOBlabel.Size = new System.Drawing.Size(33, 13);
            this.DOBlabel.TabIndex = 2;
            this.DOBlabel.Text = "DOB:";
            // 
            // Commentlabel
            // 
            this.Commentlabel.AutoSize = true;
            this.Commentlabel.Location = new System.Drawing.Point(16, 128);
            this.Commentlabel.Name = "Commentlabel";
            this.Commentlabel.Size = new System.Drawing.Size(54, 13);
            this.Commentlabel.TabIndex = 3;
            this.Commentlabel.Text = "Comment:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(117, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 66);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(117, 128);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 7;
            // 
            // btnPatientReschedule
            // 
            this.btnPatientReschedule.Location = new System.Drawing.Point(19, 177);
            this.btnPatientReschedule.Name = "btnPatientReschedule";
            this.btnPatientReschedule.Size = new System.Drawing.Size(75, 23);
            this.btnPatientReschedule.TabIndex = 8;
            this.btnPatientReschedule.Text = "Reschedule";
            this.btnPatientReschedule.UseVisualStyleBackColor = true;
            this.btnPatientReschedule.Click += new System.EventHandler(this.btnPatientReschedule_Click);
            // 
            // btnPatientSave
            // 
            this.btnPatientSave.Location = new System.Drawing.Point(161, 177);
            this.btnPatientSave.Name = "btnPatientSave";
            this.btnPatientSave.Size = new System.Drawing.Size(94, 23);
            this.btnPatientSave.TabIndex = 9;
            this.btnPatientSave.Text = "Save Continue";
            this.btnPatientSave.UseVisualStyleBackColor = true;
            this.btnPatientSave.Click += new System.EventHandler(this.btnPatientSave_Click);
            // 
            // PatientApptDateTimepicker
            // 
            this.PatientApptDateTimepicker.Location = new System.Drawing.Point(55, 3);
            this.PatientApptDateTimepicker.Name = "PatientApptDateTimepicker";
            this.PatientApptDateTimepicker.Size = new System.Drawing.Size(200, 20);
            this.PatientApptDateTimepicker.TabIndex = 4;
            this.PatientApptDateTimepicker.ValueChanged += new System.EventHandler(this.PatientApptDateTimepicker_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Gender:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(88, 99);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(48, 17);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(158, 99);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(59, 17);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // FrmPatientAppt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(274, 212);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPatientSave);
            this.Controls.Add(this.btnPatientReschedule);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.PatientApptDateTimepicker);
            this.Controls.Add(this.Commentlabel);
            this.Controls.Add(this.DOBlabel);
            this.Controls.Add(this.UsernameLabel);
            this.Controls.Add(this.PatientDatelabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmPatientAppt";
            this.Text = "PatientAppt";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PatientDatelabel;
        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.Label DOBlabel;
        private System.Windows.Forms.Label Commentlabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btnPatientReschedule;
        private System.Windows.Forms.Button btnPatientSave;
        private System.Windows.Forms.DateTimePicker PatientApptDateTimepicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}