﻿namespace Project_Form_1
{
    partial class FrmDoctorAvailability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDoctorAvailability));
            this.DocAvailabilityLabel = new System.Windows.Forms.Label();
            this.DoctorAvaildateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.DoctorNamelabel = new System.Windows.Forms.Label();
            this.txtDoctorName = new System.Windows.Forms.TextBox();
            this.BadgeIDlabel = new System.Windows.Forms.Label();
            this.txtDoctorID = new System.Windows.Forms.TextBox();
            this.btnDocReschedule = new System.Windows.Forms.Button();
            this.btnDocAvailableSave = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new Project_Form_1.DataSet1();
            this.doctor_tblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.doctor_tblTableAdapter = new Project_Form_1.DataSet1TableAdapters.Doctor_tblTableAdapter();
            this.tableAdapterManager = new Project_Form_1.DataSet1TableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctor_tblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // DocAvailabilityLabel
            // 
            this.DocAvailabilityLabel.AutoSize = true;
            this.DocAvailabilityLabel.Location = new System.Drawing.Point(17, 16);
            this.DocAvailabilityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DocAvailabilityLabel.Name = "DocAvailabilityLabel";
            this.DocAvailabilityLabel.Size = new System.Drawing.Size(112, 17);
            this.DocAvailabilityLabel.TabIndex = 0;
            this.DocAvailabilityLabel.Text = "Availability Date:";
            // 
            // DoctorAvaildateTimePicker1
            // 
            this.DoctorAvaildateTimePicker1.Location = new System.Drawing.Point(135, 9);
            this.DoctorAvaildateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DoctorAvaildateTimePicker1.Name = "DoctorAvaildateTimePicker1";
            this.DoctorAvaildateTimePicker1.Size = new System.Drawing.Size(265, 22);
            this.DoctorAvaildateTimePicker1.TabIndex = 1;
            this.DoctorAvaildateTimePicker1.ValueChanged += new System.EventHandler(this.DoctorAvaildateTimePicker1_ValueChanged);
            // 
            // DoctorNamelabel
            // 
            this.DoctorNamelabel.AutoSize = true;
            this.DoctorNamelabel.Location = new System.Drawing.Point(17, 52);
            this.DoctorNamelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DoctorNamelabel.Name = "DoctorNamelabel";
            this.DoctorNamelabel.Size = new System.Drawing.Size(68, 17);
            this.DoctorNamelabel.TabIndex = 2;
            this.DoctorNamelabel.Text = "Dr Name:";
            // 
            // txtDoctorName
            // 
            this.txtDoctorName.Location = new System.Drawing.Point(135, 52);
            this.txtDoctorName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDoctorName.Name = "txtDoctorName";
            this.txtDoctorName.Size = new System.Drawing.Size(132, 22);
            this.txtDoctorName.TabIndex = 3;
            // 
            // BadgeIDlabel
            // 
            this.BadgeIDlabel.AutoSize = true;
            this.BadgeIDlabel.Location = new System.Drawing.Point(21, 87);
            this.BadgeIDlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BadgeIDlabel.Name = "BadgeIDlabel";
            this.BadgeIDlabel.Size = new System.Drawing.Size(66, 17);
            this.BadgeIDlabel.TabIndex = 4;
            this.BadgeIDlabel.Text = "BadgeID:";
            // 
            // txtDoctorID
            // 
            this.txtDoctorID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctor_tblBindingSource, "DoctorID", true));
            this.txtDoctorID.Location = new System.Drawing.Point(135, 87);
            this.txtDoctorID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDoctorID.Name = "txtDoctorID";
            this.txtDoctorID.Size = new System.Drawing.Size(132, 22);
            this.txtDoctorID.TabIndex = 5;
            // 
            // btnDocReschedule
            // 
            this.btnDocReschedule.Location = new System.Drawing.Point(21, 138);
            this.btnDocReschedule.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDocReschedule.Name = "btnDocReschedule";
            this.btnDocReschedule.Size = new System.Drawing.Size(121, 55);
            this.btnDocReschedule.TabIndex = 6;
            this.btnDocReschedule.Text = "Please Reschedule";
            this.btnDocReschedule.UseVisualStyleBackColor = true;
            this.btnDocReschedule.Click += new System.EventHandler(this.btnDocReschedule_Click);
            // 
            // btnDocAvailableSave
            // 
            this.btnDocAvailableSave.Location = new System.Drawing.Point(223, 138);
            this.btnDocAvailableSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDocAvailableSave.Name = "btnDocAvailableSave";
            this.btnDocAvailableSave.Size = new System.Drawing.Size(135, 55);
            this.btnDocAvailableSave.TabIndex = 7;
            this.btnDocAvailableSave.Text = "Available Save Continue";
            this.btnDocAvailableSave.UseVisualStyleBackColor = true;
            this.btnDocAvailableSave.Click += new System.EventHandler(this.btnDocAvailableSave_Click);
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this.dataSet1;
            this.bindingSource1.Position = 0;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // doctor_tblBindingSource
            // 
            this.doctor_tblBindingSource.DataMember = "Doctor_tbl";
            this.doctor_tblBindingSource.DataSource = this.dataSet1;
            // 
            // doctor_tblTableAdapter
            // 
            this.doctor_tblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AppointmentSchedule_tblTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Doctor_tblTableAdapter = this.doctor_tblTableAdapter;
            this.tableAdapterManager.Insurance_tblTableAdapter = null;
            this.tableAdapterManager.Patient_tblTableAdapter = null;
            this.tableAdapterManager.Pharmacy_tblTableAdapter = null;
            this.tableAdapterManager.Representative_tblTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Project_Form_1.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // FrmDoctorAvailability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(421, 242);
            this.Controls.Add(this.btnDocAvailableSave);
            this.Controls.Add(this.btnDocReschedule);
            this.Controls.Add(this.txtDoctorID);
            this.Controls.Add(this.BadgeIDlabel);
            this.Controls.Add(this.txtDoctorName);
            this.Controls.Add(this.DoctorNamelabel);
            this.Controls.Add(this.DoctorAvaildateTimePicker1);
            this.Controls.Add(this.DocAvailabilityLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmDoctorAvailability";
            this.Text = "Doctor Schedule";
            this.Load += new System.EventHandler(this.FrmDoctorAvailability_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctor_tblBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DocAvailabilityLabel;
        private System.Windows.Forms.DateTimePicker DoctorAvaildateTimePicker1;
        private System.Windows.Forms.Label DoctorNamelabel;
        private System.Windows.Forms.TextBox txtDoctorName;
        private System.Windows.Forms.Label BadgeIDlabel;
        private System.Windows.Forms.TextBox txtDoctorID;
        private System.Windows.Forms.Button btnDocReschedule;
        private System.Windows.Forms.Button btnDocAvailableSave;
        private System.Windows.Forms.BindingSource bindingSource1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource doctor_tblBindingSource;
        private DataSet1TableAdapters.Doctor_tblTableAdapter doctor_tblTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
    }
}