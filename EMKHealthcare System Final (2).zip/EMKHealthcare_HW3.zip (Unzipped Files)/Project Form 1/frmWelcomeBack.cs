﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class frmWelcomeBack : Form
    {
        public frmWelcomeBack()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
              
        }
        private void label_forname(object sender, EventArgs e)
        {
            

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void demographicsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void process1_Exited(object sender, EventArgs e)
        {

        }

        private void frmWelcomeBack_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Doctor_tbl' table. You can move, or remove it, as needed.
            this.doctor_tblTableAdapter.Fill(this.dataSet1.Doctor_tbl);
            // TODO: This line of code loads data into the 'dataSet1.Patient_tbl' table. You can move, or remove it, as needed.
            this.patient_tblTableAdapter.Fill(this.dataSet1.Patient_tbl);
            // TODO: This line of code loads data into the 'dataSet1.AppointmentSchedule_tbl' table. You can move, or remove it, as needed.
            this.appointmentSchedule_tblTableAdapter.Fill(this.dataSet1.AppointmentSchedule_tbl);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            this.patient_tblBindingSource.EndEdit();
            this.patient_tblTableAdapter.Update(this.dataSet1.Patient_tbl);
            MessageBox.Show("Appointment Created");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.patient_tblBindingSource.AddNew();            
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
           
            
        }
    }

}
