﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class frmNewPatient : Form
    {
        public frmNewPatient()
        {
            InitializeComponent();
        }

        private void importantToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void importantToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmNewPatient frm0 = new frmNewPatient();
            frm0.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Patient Added Successfully");
            this.patient_tblBindingSource.EndEdit();
            this.patient_tblTableAdapter.Update(this.dataSet1.Patient_tbl);
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void frmNewPatient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Patient_tbl' table. You can move, or remove it, as needed.
            this.patient_tblTableAdapter.Fill(this.dataSet1.Patient_tbl);

        }

        private void btnAddnew_Click(object sender, EventArgs e)
        {
            this.patient_tblBindingSource.AddNew();
        }
    }
}
