﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class FrmDoctorAvailability : Form
    {
        public FrmDoctorAvailability()
        {
            InitializeComponent();
        }

        private void DoctorAvaildateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            this.doctor_tblBindingSource.EndEdit();
            this.doctor_tblTableAdapter.Update(this.dataSet1.Doctor_tbl);

        }

        private void btnDocAvailableSave_Click(object sender, EventArgs e)
        {
            FrmDoctorDashboard frmDD = new FrmDoctorDashboard();
            frmDD.ShowDialog();
        }

        private void btnDocReschedule_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dear Receptionist Please Reschedule this appointment, the Doctor is unavailable this day.");
            FrmReceptionistDashboard frmRD = new FrmReceptionistDashboard();
            frmRD.ShowDialog();
        }

        private void FrmDoctorAvailability_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Doctor_tbl' table. You can move, or remove it, as needed.
            this.doctor_tblTableAdapter.Fill(this.dataSet1.Doctor_tbl);

        }
    }
}
