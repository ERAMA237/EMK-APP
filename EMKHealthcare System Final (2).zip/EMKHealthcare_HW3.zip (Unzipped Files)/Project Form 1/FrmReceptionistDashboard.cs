﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class FrmReceptionistDashboard : Form
    {
        public FrmReceptionistDashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmPatientSelectAppt FrmPSA = new FrmPatientSelectAppt();
                FrmPSA.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmDoctorSelectAvailability frmDSA3 = new FrmDoctorSelectAvailability();
            frmDSA3.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmMainPage frmMP = new frmMainPage();
            frmMP.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmDoctorDashboard frmDD = new FrmDoctorDashboard();
            frmDD.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Appointment Created");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Appointment Created");
        }
    }
}
