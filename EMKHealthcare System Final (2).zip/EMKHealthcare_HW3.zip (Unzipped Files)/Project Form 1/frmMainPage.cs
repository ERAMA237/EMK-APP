﻿using Project_Form_1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class frmMainPage : Form
    {
        public frmMainPage()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            frmExistingPatient frm2 = new frmExistingPatient();
            frm2.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnNewPatient_Click(object sender, EventArgs e)
        {

            
            frmNewPatient frm0 = new frmNewPatient();
            frm0.ShowDialog();
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            frmReceptionistLogin frmRL = new frmReceptionistLogin();
            frmRL.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            FrmDoctorLogin frmDL = new FrmDoctorLogin();
            frmDL.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            formsignature frmPh = new formsignature();
            frmPh.ShowDialog();
        }
    }
}
