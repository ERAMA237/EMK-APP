﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class FrmPatientAppt : Form
    {
        public FrmPatientAppt()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker5_ValueChanged(object sender, EventArgs e)
        {

        }

        private void PatientApptDateTimepicker_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void btnPatientSave_Click(object sender, EventArgs e)
        {
            FrmReceptionistDashboard frmRD = new FrmReceptionistDashboard();
            frmRD.ShowDialog();
        }

        private void btnPatientReschedule_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dear Patient Please Reschedule, the Doctor is unavailable this day.");
        }
    }
}
