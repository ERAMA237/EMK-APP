﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class frmReceptionistLogin : Form
    {
        public frmReceptionistLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmReceptionistDashboard frmRD = new FrmReceptionistDashboard();
            frmRD.ShowDialog();
        }
    }
}
