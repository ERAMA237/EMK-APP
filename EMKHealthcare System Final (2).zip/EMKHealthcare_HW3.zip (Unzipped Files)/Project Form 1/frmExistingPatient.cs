﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Project_Form_1
{
    public partial class frmExistingPatient : Form
    {
        public frmExistingPatient()
        {
            InitializeComponent();
            

        }
        
        private void PhoneNo_Click(object sender, EventArgs e)
        {

        }

        private void btnVerify_Click(object sender, EventArgs e)
        {

                        
                if (patient_tblBindingSource.DataSource.ToString() =="1")
                {
                MessageBox.Show("Please enter correct username and password", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                }
                else
                {
                
                frmWelcomeBack frm4 = new frmWelcomeBack();
                frm4.ShowDialog();
                
                }
        }

        private void frmExistingPatient_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Patient_tbl' table. You can move, or remove it, as needed.
            this.patient_tblTableAdapter.Fill(this.dataSet1.Patient_tbl);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tbxLastName1_TextChanged_1(object sender, EventArgs e)
        {
        
        
        }
    }



    
}
