﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class FrmDoctorLogin : Form
    {
        public FrmDoctorLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.doctor_tblBindingSource.EndEdit();
            this.doctor_tblTableAdapter.Update(this.dataSet1.Doctor_tbl); 
            FrmDoctorDashboard frmDD = new FrmDoctorDashboard();
            frmDD.ShowDialog();
        }
        
        
        
            
        
        

        private void FrmDoctorLogin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.Doctor_tbl' table. You can move, or remove it, as needed.
            this.doctor_tblTableAdapter.Fill(this.dataSet1.Doctor_tbl);

        }
    }
}
