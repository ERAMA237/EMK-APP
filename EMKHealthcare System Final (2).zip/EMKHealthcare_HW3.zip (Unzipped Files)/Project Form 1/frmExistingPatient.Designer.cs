﻿
using System;

namespace Project_Form_1
{
    partial class frmExistingPatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExistingPatient));
            this.PhoneNo = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.patient_tblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new Project_Form_1.DataSet1();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxLastName1 = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.tbxDOB2 = new System.Windows.Forms.MaskedTextBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.patient_tblTableAdapter = new Project_Form_1.DataSet1TableAdapters.Patient_tblTableAdapter();
            this.tableAdapterManager = new Project_Form_1.DataSet1TableAdapters.TableAdapterManager();
            ((System.ComponentModel.ISupportInitialize)(this.patient_tblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // PhoneNo
            // 
            this.PhoneNo.AutoSize = true;
            this.PhoneNo.Location = new System.Drawing.Point(69, 112);
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.Size = new System.Drawing.Size(67, 17);
            this.PhoneNo.TabIndex = 0;
            this.PhoneNo.Text = "PhoneNo";
            this.PhoneNo.Click += new System.EventHandler(this.PhoneNo_Click);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patient_tblBindingSource, "Patient_Cellphone", true));
            this.maskedTextBox1.Location = new System.Drawing.Point(150, 109);
            this.maskedTextBox1.Mask = "(999) 000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(205, 22);
            this.maskedTextBox1.TabIndex = 1;
            // 
            // patient_tblBindingSource
            // 
            this.patient_tblBindingSource.DataMember = "Patient_tbl";
            this.patient_tblBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(409, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please Verify Your Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "DOB";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Username";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // tbxLastName1
            // 
            this.tbxLastName1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patient_tblBindingSource, "Patient_Lastname", true));
            this.tbxLastName1.Location = new System.Drawing.Point(150, 69);
            this.tbxLastName1.Name = "tbxLastName1";
            this.tbxLastName1.Size = new System.Drawing.Size(205, 22);
            this.tbxLastName1.TabIndex = 6;
            this.tbxLastName1.TextChanged += new System.EventHandler(this.tbxLastName1_TextChanged_1);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSearch.Location = new System.Drawing.Point(265, 207);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(186, 35);
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // tbxDOB2
            // 
            this.tbxDOB2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patient_tblBindingSource, "Patient_DOB", true));
            this.tbxDOB2.Location = new System.Drawing.Point(151, 155);
            this.tbxDOB2.Mask = "00/00/0000";
            this.tbxDOB2.Name = "tbxDOB2";
            this.tbxDOB2.Size = new System.Drawing.Size(203, 22);
            this.tbxDOB2.TabIndex = 8;
            this.tbxDOB2.ValidatingType = typeof(System.DateTime);
            // 
            // bindingSource1
            // 
            this.bindingSource1.AllowNew = false;
            this.bindingSource1.DataSource = this.dataSet1;
            this.bindingSource1.Position = 0;
            // 
            // patient_tblTableAdapter
            // 
            this.patient_tblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AppointmentSchedule_tblTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Doctor_tblTableAdapter = null;
            this.tableAdapterManager.Insurance_tblTableAdapter = null;
            this.tableAdapterManager.Patient_tblTableAdapter = this.patient_tblTableAdapter;
            this.tableAdapterManager.Pharmacy_tblTableAdapter = null;
            this.tableAdapterManager.Representative_tblTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Project_Form_1.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // frmExistingPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbxDOB2);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.tbxLastName1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.PhoneNo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmExistingPatient";
            this.Text = "ExistingPatient";
            this.Load += new System.EventHandler(this.frmExistingPatient_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.patient_tblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PhoneNo;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSearch;
        public System.Windows.Forms.TextBox tbxLastName1;
        private System.Windows.Forms.MaskedTextBox tbxDOB2;
        private EventHandler frmExistingPatient_Load;
        private readonly EventHandler tbxLastName1_TextChanged;
        private System.Windows.Forms.BindingSource bindingSource1;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource patient_tblBindingSource;
        private DataSet1TableAdapters.Patient_tblTableAdapter patient_tblTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
    }
}