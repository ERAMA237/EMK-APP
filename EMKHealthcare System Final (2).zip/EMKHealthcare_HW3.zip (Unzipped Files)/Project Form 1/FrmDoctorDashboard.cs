﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Form_1
{
    public partial class FrmDoctorDashboard : Form
    {
        public FrmDoctorDashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmDoctorAvailability frmDA2 = new FrmDoctorAvailability();
            frmDA2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmDoctorSelectAvailability frmDSA3 = new FrmDoctorSelectAvailability();
            frmDSA3.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmDoctorMedical frmDM = new FrmDoctorMedical();
            frmDM.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmReceptionistDashboard frmRD = new FrmReceptionistDashboard();
            frmRD.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmMainPage frmMP = new frmMainPage();
            frmMP.ShowDialog();
        }
    }
}
